
  # Simple Text Submission Page

  This is a code bundle for Simple Text Submission Page. The original project is available at https://www.figma.com/design/ljHGyFL1qDWuCPtImW3RKO/Simple-Text-Submission-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  